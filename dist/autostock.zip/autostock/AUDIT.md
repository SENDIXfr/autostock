# Audit autostock — 12 octobre 2026

Audit du module 2.0.0, avec corrections livrées dans la version 2.1.0. Périmètre : code PHP, configuration, cron, requêtes SQL, multiboutique, tests et archive de distribution. Aucune boutique de production n’a été modifiée.

Le projet porte désormais le nom technique `autostock` : fichier principal `autostock.php`, espace de noms `Autostock`, domaine de traduction `Modules.Autostock.Admin`, clés `AUTOSTOCK_*` et table `<préfixe>autostock_disabled`. Le passage depuis une copie installée sous un autre nom constitue une nouvelle installation ; la récupération des réglages et du suivi est décrite dans le README.

## Constats corrigés

| Priorité | Constat | Correction |
| --- | --- | --- |
| Haute | `Tools::jsonEncode()` n’existe pas dans PrestaShop 9.2. Le cron pouvait modifier les produits puis échouer lors de la réponse. | Utilisation de `json_encode()`, test des réponses et erreurs HTTP dans onze sous-processus PHP. |
| Haute | `getModuleLink()` recevait la boutique en cinquième argument, réservé à la langue. | Langue par défaut de la boutique en cinquième argument, boutique en sixième : domaine et langue corrects. |
| Haute | `Configuration::get()` recevait la boutique cible mais conservait le groupe du contexte courant. | Passage explicite du groupe de la boutique cible. |
| Haute | Le cron acceptait une autre boutique sans vérifier l’activation du module pour celle-ci. | Contrôle de `module_shop` ; les exécutions groupées et URL ignorent les boutiques inactives ou sans module activé. |
| Haute | Deux processus pouvaient modifier simultanément le suivi et l’activation d’une même boutique. | Verrou nommé acquis avant la transaction, libéré après succès ou échec ; réponse HTTP `409` si occupé. |
| Moyenne | Les écritures SQL laissaient `product.active` et les caches internes potentiellement incohérents. | Alignement de `product` sur sa boutique par défaut pour les produits suivis ; invalidation des caches après changement. |
| Moyenne | Les actions de configuration dépendaient des protections du contrôleur appelant, sans contrôle propre au module. | Vérification POST, session employé, droit de configuration et jeton de formulaire dédié. |
| Moyenne | La rotation du jeton affichait une réussite même si l’écriture échouait. | Contrôle du résultat ; lecture globale cohérente du jeton ; génération avec `random_bytes(32)`. |
| Moyenne | L’initialisation front-office chargeait le thème et pouvait interrompre le cron en maintenance. | Traitement et authentification dans `init()`, sans initialisation du front-office. |
| Moyenne | Le moteur de la table de suivi dépendait du moteur par défaut, malgré l’usage de transactions. | InnoDB à l’installation et conversion par le script de mise à niveau 2.1.0, sans suppression du suivi. |
| Moyenne | Les tests ne couvraient ni le contrôleur cron, ni les réglages et permissions. | Trois suites isolées, test SQL d’intégration et workflow CI avec plusieurs versions PHP et moteurs SQL. |
| Faible | La compatibilité déclarée couvrait par anticipation toutes les versions 9 ; le ZIP devait être maintenu manuellement. | Plafond `9.2.99` ; reconstruction et vérification de l’archive avec une liste explicite de fichiers. |

## Vérifications effectuées localement

- PHP 8.4.22 : validation syntaxique de tous les fichiers PHP et exécution des trois suites isolées.
- `composer validate --strict` et `composer test` : réussis (Composer lancé avec l’extension OpenSSL activée pour cette commande).
- Tests du contrôleur cron : jetons absents, incorrects ou sous forme de tableau ; boutique par défaut ou explicite ; identifiants malformés ; boutique désactivée ; verrou occupé ; exception interne sans divulgation des détails.
- Revue des signatures et méthodes utilisées dans les sources officielles PrestaShop 9.2.0.
- Vérification du contenu, des versions et de l’intégrité de `dist/autostock.zip`.

Les tests isolés utilisent des doublures des classes PrestaShop. Aucun serveur MySQL/MariaDB ni boutique PrestaShop complète n’est disponible dans cet environnement ; le test SQL d’intégration et le workflow GitHub Actions n’ont donc pas été exécutés ici. La déclaration de compatibilité et la revue des API ne constituent pas une certification sur boutique réelle.

## Recette restante sur une boutique PrestaShop 9.2 de test

1. Importer le ZIP et installer `autostock`, ou mettre à niveau une copie de la version 2.0.0 portant déjà ce nom ; vérifier le seuil, le jeton et le suivi. Pour une copie installée sous un autre nom, suivre la procédure de récupération des données du README.
2. Avec un produit actif à stock nul, exécuter le cron, vérifier sa désactivation et le compteur ; remettre du stock et vérifier sa réactivation.
3. Vérifier qu’un produit désactivé manuellement reste désactivé et qu’une sauvegarde de fiche retire bien son suivi.
4. Refaire les scénarios avec des déclinaisons, un seuil négatif, deux domaines/langues de boutique et un groupe à stock partagé.
5. Vérifier les droits d’un employé restreint, les formulaires réels du back-office, la rotation du jeton et une exécution en maintenance.
6. Vérifier l’affichage avec le thème et les modules de cache, recherche ou catalogue réellement installés.

## Limites et améliorations suivantes

- `actionProductUpdate` ne distingue pas une sauvegarde manuelle d’une sauvegarde par import ou module tiers. Le suivi est retiré dans les deux cas, comme auparavant. Une gestion plus précise nécessite de définir une règle d’exclusion ou de détecter les changements explicites de statut.
- Les mises à jour SQL évitent le chargement de tous les objets `Product`, mais ne déclenchent pas les hooks individuels de sauvegarde. Les modules de cache externe, moteur de recherche ou export qui dépendent de ces hooks doivent être vérifiés en recette. L’invalidation ajoutée couvre les caches internes de PrestaShop.
- Les transactions supposent également des tables cœur transactionnelles, ce qui doit être vérifié sur les installations anciennes. La migration ne convertit que la table du module.
- Le verrou coordonne les exécutions de ce module ; il ne bloque pas les importateurs ou commandes externes qui écrivent les stocks. La prochaine exécution réévalue le stock courant.
- Sur un gros catalogue, mesurer la durée et les verrous SQL avant d’augmenter la fréquence du cron. Un découpage par lots, un mode simulation et un historique détaillé constituent des évolutions possibles.
- Le jeton cron est global et figure dans les URL du planificateur. Sa portée et son caractère secret sont documentés ; les journaux d’URL doivent être gérés par l’exploitant.

## Références officielles

- [Annonce de PrestaShop 9.2.0](https://build.prestashop-project.org/news/2026/prestashop-9-2-0-available/).
- [Changements pour les modules en 9.2](https://devdocs.prestashop-project.org/9/modules/core-updates/9.2/).
- [Link.php — tag 9.2.0](https://github.com/PrestaShop/PrestaShop/blob/9.2.0/classes/Link.php) : arguments de `getModuleLink()`.
- [Tools.php — tag 9.2.0](https://github.com/PrestaShop/PrestaShop/blob/9.2.0/classes/Tools.php) : absence de `jsonEncode()`.
- [Configuration.php — tag 9.2.0](https://github.com/PrestaShop/PrestaShop/blob/9.2.0/classes/Configuration.php) : héritage boutique/groupe et `getGlobalValue()`.
- [StockAvailable.php — tag 9.2.0](https://github.com/PrestaShop/PrestaShop/blob/9.2.0/classes/stock/StockAvailable.php) : restriction multiboutique et stock agrégé.
- [Product.php — tag 9.2.0](https://github.com/PrestaShop/PrestaShop/blob/9.2.0/classes/Product.php) : invalidation des caches et hook de mise à jour.
- [Dépendances de PrestaShop 9.2.0](https://github.com/PrestaShop/PrestaShop/blob/9.2.0/composer.json) : PHP 8.1 minimum pour le cœur.
